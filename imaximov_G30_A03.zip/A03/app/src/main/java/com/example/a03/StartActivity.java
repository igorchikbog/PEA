package com.example.a03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
    }
    public void existingUser(View view){
        Intent intent = new Intent(this, ExistingUserActivity.class);
        startActivity(intent);
    }
    public void newUser(View view){
        Intent intent = new Intent(this, NewUserActivity.class);
        startActivity(intent);
    }
}