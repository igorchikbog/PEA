package com.example.a03;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class ExistingUserActivity extends AppCompatActivity {
    HangmanGameStart hangmanGameStart;
    EditText username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_existing_user);
        username = findViewById(R.id.editTextTextPersonName2);

    }

    public void enterButton(View view) {
        hangmanGameStart = new HangmanGameStart(this,"dictionary.txt");

        if(!username.getText().toString().isEmpty()){
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("user",username.getText().toString());
            startActivity(intent);
        }else {
            AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
            builder1.setCancelable(true);
            builder1.setMessage("Please enter a username");

            builder1.setPositiveButton(
                    "Ok",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
            builder1.show();
        }
    }
}