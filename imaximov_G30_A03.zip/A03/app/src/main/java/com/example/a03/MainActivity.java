package com.example.a03;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static MainActivity main = new MainActivity();

    public static MainActivity getInstance() {
        return main;
    }

    private HangmanLogic game;
    private HangmanGameStart hangmanGameStart;
    private boolean gameInProgress = false;
    private int initializeDictionaryOutput;
    TextView txtPaneWordDisplay;
    ImageView img;
    int images[]={R.drawable.hangman0,R.drawable.hangman1,R.drawable.hangman2,R.drawable.hangman3,R.drawable.hangman4,R.drawable.hangman5,R.drawable.hangman6};

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView txtFldGuess = findViewById(R.id.txtFldGuess);
        final Button btnGuess = findViewById(R.id.btnGuess);
        final Button btnHint = findViewById(R.id.btnHint);
        img=findViewById(R.id.img);
        txtPaneWordDisplay = (TextView)findViewById(R.id.txtPaneWordDisplay);
        btnGuess.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                displayCheckLetterOutput();
                txtFldGuess.setText("");
            }
        });
        btnHint.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                getHint();
            }
        });
        hangmanGameStart = new HangmanGameStart(this,"dictionary.txt");
        String user=getIntent().getStringExtra("user");
        if (user!=null) {
            newGame();
            game = hangmanGameStart.getGame();
            displayLetterBlanks();
        }


    }

    private void displayContinueSavedGame() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

        builder1.setMessage("You have a saved game on file.\nDo you want to continue where you left off?");
        builder1.setCancelable(true);
        builder1.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        if (hangmanGameStart.retrieveSavedGame() && !hangmanGameStart.getGame().getGameDone()) {
                            game = hangmanGameStart.getGame();
                            int dictionaryExists;
                            dictionaryExists = hangmanGameStart.initializeDictionary();
                            if (dictionaryExists == 1) {
                                updateGame();
                            } else {
                                gameInProgress = false;
                            }
                        }
                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        newGame();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }// displayContinueSavedGame()

    private void displayCheckLetterOutput() {
        final TextView txtFldGuess = findViewById(R.id.txtFldGuess);
        int checkLetterOutput = game.checkLetter(txtFldGuess.getText().toString());
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setCancelable(true);
        if (checkLetterOutput == -1) {
            builder1.setMessage("Your input was invalid.\nYour input must be a single letter guess.");
            builder1.show();
        } else if (checkLetterOutput == -2) {
            builder1.setMessage("This letter was already guessed.\nTo see the guessed letter please refer to the bottom of the frame.");
            builder1.show();
        } else if (checkLetterOutput == -10) {
            builder1.setMessage("You made too many mistakes!\nWould you like to play again?");
            builder1.setPositiveButton(
                    "Yes",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            newGame();
                        }
                    });
            builder1.setNegativeButton(
                    "No",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            updateGame();
                        }
                    });
            builder1.show();
        } else if (checkLetterOutput == 10) {
            builder1.setMessage("You won the game!\nWould you like to play again?");
            builder1.setPositiveButton(
                    "Yes",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            newGame();
                        }
                    });
            builder1.setNegativeButton(
                    "No",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            updateGame();
                        }
                    });
            builder1.show();
        } else {
            updateGame();
        }
    }// displayCheckLetterOutput()

    private void newGame() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        if (hangmanGameStart.getNewGame()) {
            game = hangmanGameStart.getGame();
            updateGame();
        } else {
            gameInProgress = false;
            builder.setMessage("There are no more words left to play!");
            builder.show();
        }
    }// newGame()
    private void displayLetterBlanks(){
        StringBuilder str= new StringBuilder() ;
            str.append(game.getInterfaceLettersString());
        txtPaneWordDisplay.setText(str.toString());
    }
    private void updateGame() {
        TextView txtPaneWordDisplay = findViewById(R.id.txtPaneWordDisplay);
        TextView txtPaneGuessedLetters = (TextView) findViewById(R.id.textView10);
        TextView fldNumMistakes = (TextView) findViewById(R.id.textView11);
        txtPaneWordDisplay.setText(game.getInterfaceLettersString());
        txtPaneGuessedLetters.setText(game.getGuessedLettersString());
        fldNumMistakes.setText("" + game.getMistakesLeft());
        img.setImageResource(images[6-game.getMistakesLeft()]);
    }// updateGame()

    public void startGameAs(String username) {
        gameInProgress = true;
        hangmanGameStart.findUser(username);
        if (hangmanGameStart.getGame().isSavedGame(username))
            displayContinueSavedGame();
        else
            newGame();
    }// startGameAs()

    private void getHint() {
        if (game.giveHint() == 10) {
            AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
            builder1.setCancelable(true);
            builder1.setMessage("You won the game!\nWould you like to play again?");
            builder1.setPositiveButton(
                    "Yes",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            newGame();
                        }
                    });
            builder1.setNegativeButton(
                    "No",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            updateGame();
                        }
                    });
            builder1.show();
        } else
            updateGame();
    }// getHint()

    public boolean isGameInProgress() {
        return gameInProgress;
    }
}