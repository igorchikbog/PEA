package com.example.a03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ScoreboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scoreboard);
    }
}