package com.example.a03;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NewUserActivity extends AppCompatActivity {
    HangmanGameStart hangmanGameStart;
    EditText username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);
        username = findViewById(R.id.editTextTextPersonName);
        hangmanGameStart = new HangmanGameStart(this,"dictionary.txt");

    }
    public void enterButton(View view) {
        if(!username.getText().toString().isEmpty()){
            hangmanGameStart.addUser(username.getText().toString());
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("user",username.getText().toString());
            startActivity(intent);
        }else {
            AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
            builder1.setCancelable(true);
            builder1.setMessage("Please enter a username");

                    builder1.setPositiveButton(
                    "Ok",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
            builder1.show();
        }
    }

}